{{- define "iptrc-tools-common.backend.deployment" -}}
{{- if .Values.backend.enabled }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.config.k3sAppName }}-backend
  namespace: {{ .Values.namespace }}
  labels:
    app: {{ .Values.config.k3sAppName }}-backend
    app.kubernetes.io/name: {{ .Values.config.k3sAppName | quote }}
    app.kubernetes.io/part-of: {{ index .Values.labels "part-of" }}
    app.kubernetes.io/managed-by: {{ index .Values.labels "managed-by" }}
    environment: {{ .Values.labels.environment }}
    team: {{ .Values.labels.team }}
spec:
  replicas: {{ .Values.replicaCount }}
  minReadySeconds: 20
  selector:
    matchLabels:
      app: {{ .Values.config.k3sAppName }}-backend
  template:
    metadata:
      labels:
        app: {{ .Values.config.k3sAppName }}-backend
        app.kubernetes.io/name: {{ .Values.config.k3sAppName | quote }}
        app.kubernetes.io/part-of: {{ index .Values.labels "part-of" }}
        app.kubernetes.io/managed-by: {{ index .Values.labels "managed-by" }}
        environment: {{ .Values.labels.environment }}
        team: {{ .Values.labels.team }}
      #annotations:
      #  src-revision: {{ .Values.global.srcRevision | default "unknown" | quote }}
    spec:
      hostname: {{ .Values.hostname }}
      initContainers:
        - name: fix-log-permissions
          image: artifact-dmz.it.att.com/apm0012178-dkr-ecompcntr-public-stage/com.att.ecompcntr.public/busybox:latest
          command: ["sh", "-c", "chmod 1777 /var/www/logs"]
          resources:
            requests:
              memory: "32Mi"
              cpu: "10m"
            limits:
              memory: "32Mi"
              cpu: "10m"
          volumeMounts:
            - name: python-logs
              mountPath: /var/www/logs
      containers:
        - name: {{ .Values.config.k3sAppName }}-backend
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
          imagePullPolicy: {{ .Values.image.pullPolicy }}
          lifecycle:
            postStart:
              exec:
                command: ["sh", "-c", "sed -i 's/develop_str=\"develop\"/develop_str=\"whatevermate\"/g' /usr/local/bin/create-project.sh"]
          ports:
            - containerPort: 80
              name: http
              protocol: TCP
            - containerPort: 22
              name: ssh
              protocol: TCP
          envFrom:
            - configMapRef:
                name: shared-app-config
            - configMapRef:
                  name: {{ .Values.config.k3sAppName }}-config
          volumeMounts:
            - name: ssh-keys
              mountPath: /var/run/secrets
              readOnly: true
            - name: iptrc-certs
              mountPath: /opt/IptrcTools/certs
              readOnly: true
            - name: site-packages
              mountPath: /opt/site_packages
            - name: iptrctools-libs
              mountPath: /opt/iptrctools_libs
            - name: etc-ssl-certs
              mountPath: /etc/ssl/certs
              readOnly: true
            - name: ca-certificates
              mountPath: /usr/share/ca-certificates/
              readOnly: true
            - name: python-logs
              mountPath: /var/www/logs
            - name: crontab-backend
              mountPath: /var/spool/cron/crontabs/
            - name: src-backend
              mountPath: /var/www/src/IptrcFlaskApp
          resources:
            requests:
              memory: {{ .Values.resources.requests.memory | quote }}
              cpu: {{ .Values.resources.requests.cpu | quote }}
            limits:
              memory: {{ .Values.resources.limits.memory | quote }}
              cpu: {{ .Values.resources.limits.cpu | quote }}
      volumes:
        - name: ssh-keys
          secret:
            secretName: iptrc-tools-shared-app-secrets
        - name: iptrc-certs
          secret:
            secretName: iptrc-certs
            items:
            - key: tls.key
              path: tls.key
            - key: tls.crt
              path: tls.crt
            - key: tls.crt
              path: ca.crt
            - key: iptrctools.pem
              path: iptrctools.pem
            - key: iptrctools.pem
              path: iptrctools.bundle-ca.pem
        - name: site-packages
          hostPath:
            path: /home/m29251/python3.6_virtual_env/lib/python3.6/site-packages
        - name: iptrctools-libs
          hostPath:
            path: /home/m29251/hoho_scripts
        - name: etc-ssl-certs
          hostPath:
            path: /etc/ssl/certs
        - name: ca-certificates
          hostPath:
            path: /usr/share/ca-certificates/
        - name: python-logs
          hostPath:
            path: /opt/logs/pylogs/{{ .Values.config.k3sAppName }}/
            type: DirectoryOrCreate
        - name: crontab-backend
          persistentVolumeClaim:
            claimName: {{ .Values.config.k3sAppName }}-crontab-backend
        - name: src-backend
          persistentVolumeClaim:
            claimName: {{ .Values.config.k3sAppName }}-src-backend
{{- end }}
{{- end }}

